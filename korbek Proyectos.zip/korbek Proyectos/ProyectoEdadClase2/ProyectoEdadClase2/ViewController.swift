//
//  ViewController.swift
//  ProyectoEdadClase2
//
//  Created by Guest User on 8/4/15.
//  Copyright (c) 2015 Guest User. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var lblEdad: UILabel!
    
    
    @IBOutlet weak var lblcalculo: UILabel!
    
    
    @IBOutlet weak var txtedad: UITextField!
    
    
    @IBOutlet weak var txtcalculo: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    @IBAction func btnCalculo(sender: AnyObject) {
        
        var edad:Int? = self.txtedad.text.toInt()
        let reso = 2015 - edad!
        self.txtcalculo.text = String(reso)
    }
    
    
}

