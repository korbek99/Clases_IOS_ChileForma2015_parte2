//
//  ViewController.swift
//  AplicacionClase2
//
//  Created by Guest User on 8/4/15.
//  Copyright (c) 2015 Guest User. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

   // mi IBOuotlet
    
    
    
    @IBOutlet weak var lblsaludo: UILabel!

    
    @IBOutlet weak var txtNombre: UITextField!
    
    @IBOutlet weak var slilderpro: UISlider!
    
    @IBOutlet weak var lbvalorslider: UILabel!
    
    @IBOutlet weak var lblvalido: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // mi IBAction
    
    @IBAction func btnsaludar(sender: AnyObject) {
        
        
        self.lblsaludo.text  = "hola " + self.txtNombre.text
    }
    
    
    @IBAction func slider01(sender: AnyObject) {
        println("cambio slider")
        var string = self.slilderpro.value.description
        self.lbvalorslider.text = string
    }
    

    @IBAction func valido(sender: AnyObject) {
       println("cambio Segment")
        
            }
}

