//
//  ViewController.swift
//  escena01
//
//  Created by Guest User on 8/5/15.
//  Copyright (c) 2015 Guest User. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var lblnombre: UILabel!
    
    
    @IBOutlet weak var lblemail: UILabel!
    
    
    @IBOutlet weak var lblCiudad: UILabel!
    
    
    @IBOutlet weak var txtnom: UITextField!
    
    
    @IBOutlet weak var txtemail: UITextField!
    
    
    @IBOutlet weak var txtarea: UITextView!
    
    @IBOutlet weak var txtciudad: UITextField!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func btnMostrar(sender: AnyObject) {
        
        var strnom   :String = self.txtnom.text
        var stremail :String = self.txtemail.text
        var strciudad :String = self.txtciudad.text
        
        self.txtarea.text = strnom + " " + stremail + " " + strciudad
        
        
        
        
    }

}

