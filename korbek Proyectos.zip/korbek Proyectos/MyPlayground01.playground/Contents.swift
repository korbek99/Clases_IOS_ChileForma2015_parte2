//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
var myInt=25
var myDouble=3.14
var myString = "Kermit"
var myString2: String = "Korbek"
var myString3: String = myString + "," + myString2
var myString4: String = myString + "," + myString

//println("Yo tengo (myInt) años ")
var movie:String? = "Attack of the Killer Tomatoes"
println(movie!)











